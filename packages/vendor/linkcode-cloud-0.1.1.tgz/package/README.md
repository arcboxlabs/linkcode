# @linkcode/cloud

Official bindings from LinkCode to hosted LinkCode Cloud pages. The hosted
Console owns offer selection, amounts, checkout, and payment status; this
package exposes none of those APIs.

## Hosted billing

```ts
import { createHostedBillingUrl } from "@linkcode/cloud";

const url = createHostedBillingUrl({
  returnTarget: "linkcode://billing/return",
});

// Open `url` in the user's browser.
```

`returnTarget` is optional and accepts only `linkcode://`,
`linkcode-dev://`, or their profile-suffixed forms such as
`linkcode-dev-alpha://`. When omitted, the URL opens normal browser billing.
After Stripe Checkout, LinkCode receives only the custom-scheme navigation
with the authoritative internal `order` parameter and optional
`canceled=true`; it must not infer payment success from that navigation.
